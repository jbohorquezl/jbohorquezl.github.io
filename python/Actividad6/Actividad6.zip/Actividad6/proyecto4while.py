#App que muestre los números impares del 1 al 100

i=1
while i<=100:
    print(i)
    i=i+2