#App que muestre la multiplicacion de los numero del 1 al 100
    
i=1
mul=1
while i<=100:
    mul=mul*i
    i+=1
    print(mul)
