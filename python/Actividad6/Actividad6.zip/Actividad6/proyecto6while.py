#App que muestre la suma de los numero del 1 al 100

i=1
sum=0
while i<=100:
    sum=sum+i
    i+=1
    print(sum)