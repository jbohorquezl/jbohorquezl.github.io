#Diseñar una app que pida al usuario una palabra y la muestre 10 veces por pantalla.

pal=str(input("Ingrese una palabra: "))

print(pal)
print(pal)
print(pal)
print(pal)
print(pal)
print(pal)
print(pal)
print(pal)
print(pal)
print(pal)

i=pal
for i in range(1,11):
    print(pal)
