#Diseñar una app que pregunte al usuario la edad y muestre por pantalla todos los años que ha cumplido (desde 1 hasta su edad).

x=int(input("Ingrese su edad: "))

print("Años que a cumplido: ")

i=1
while i<=x:
    print(i)
    i+=1
    
