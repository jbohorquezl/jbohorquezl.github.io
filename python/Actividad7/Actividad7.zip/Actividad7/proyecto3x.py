#Diseñar una app que al ingresar un número entero positivo, muestre en pantalla todos los números impares (desde 1 hasta el número ingresado separado por comas) 

x=int(input("Ingrese un número: "))

i=1
while i<=x:
    print(i , end=",")
    i+=2