#5.	Diseñe una app que almacene una cadena de caracteres contraseña en una variable, pregunte al usuario por la contraseña hasta que introduzca la contraseña correcta.

contraseña = "contraseña"
password= ""
while password != contraseña:
    password = input("Introduce la contraseña: ")
print("Contraseña correcta")
