# 1.	Diseñe una app que al ingresar los valores de x que muestre 
# por pantalla el resultado de la siguiente operación:

x=int(input("Ingrese el valor de x: "))
n=(-3)/(pow(x,4))
print("El resultado es: ",n)