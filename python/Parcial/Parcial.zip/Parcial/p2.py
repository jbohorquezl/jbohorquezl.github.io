# 2.	Diseñe una app que, al ingresar el Nombre, No de Celular, Correo, Año de Nacimiento, debe mostrar por pantalla un mensaje concatenando todos los valores.
nombre=str(input("Ingrese su nombre: "))
N_cel=int(input("Ingrese el número de Celular: "))
email=str((input("Ingrese el correo: ")))
nac=int(input("Ingrese el año de nacimiento: "))

print(" Nombre:            ", nombre, "\n N° Celular:        ",N_cel, "\n Correo:            ",email, "\n Año de Nacimiento: ",nac)