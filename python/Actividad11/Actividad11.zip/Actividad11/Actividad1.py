#Diseñe una app que reciba una lista vacia, dicha lista el usuario define su tamaño y los valores de cada elemento
#La app debe mostrar los valores de la lista actualizada
#Una lista vacia para capturar 
# Correo
# N° Telefono
# Dirreción
# Fecha de nacimiento
# Lugar de Naciemiento

#Crear listas vacias
nombres = []
identificacion = []
email = []
celular = []
direccion = []
fecha_nacimiento = []
lugar_nacimiento = []

#Definimos un tamaño para las listas
tamaño = int(input("¿ Tamaño de la lista ?: "))
#Recorrer la lista
print("=======================================")
print("     INFORMACIÓN DEL APRENDIZ        ")
print("=======================================")
for i in range (tamaño):
    print("\nIngrese los datos del aprendiz ", i + 1 ,":")
    print("---------------------------------------")
    nombre = input("Nombre del aprendiz: " )
    nombres.append(nombre)
    ident = input("Identificación del aprendiz: ")
    identificacion.append(ident)
    correo = input("Email: ")
    email.append(correo)
    tel = input("N° Telefono: ")
    celular.append(tel)
    dirr = input("Direccion: ")
    direccion.append(dirr)
    fnac = input("Fecha de Nacimiento: ")
    fecha_nacimiento.append(fnac)
    lnac = input("Lugar de Nacimiento: ")
    lugar_nacimiento.append(lnac)
    print("---------------------------------------")
print("\n=======================================")
print("       INFORMACIÓN DEL APRENDIZ        ")
print("=======================================")
#Mostrar lista
for i in range(tamaño):
    print("\n---------------------------------------")
    #nombres.sort para ordenar alfabeticamente
    print("              APRENDIZ ",i + 1)
    print(" \n Nombre: ", nombres[i])
    print(" Indentificación: ", identificacion[i])
    print(" Email: ", email[i])
    print(" N° Telefono: ", celular[i])
    print(" Dirrecion: ", direccion[i])
    print(" Fecha de Nacimiento: ", fecha_nacimiento[i])
    print(" Lugar de Nacimiento: ", lugar_nacimiento[i])
print("---------------------------------------")
