#Diseñe una app que permita almacenar la información de los clientes de una empresa. 
# Los clientes se guardaran en un diccionario llamado clientes. LOs datos deben ser ingresados por el usuario, identificación del cliente, nombre, dirección, telefono, correo y empresa. 
# La app debe preguntar al usuario por una opción del menú: 
# 1) Añadir cliente. 
# 2) Mostrar cliente. 
# 3) Eliminar cliente. 
# 4) Salir.

clientes={}
op=""
while op !=4:
    if op==1:
        print("\n========================================")
        print(">>>      INFORMACIÓN DEL CLIENTE    <<<")
        print("========================================\n")
        identificacion=input("| Digite su identificación: ")
        nombre=input("| Escriba su nombre: ")
        direccion=input("| Escriba su dirección: ")
        telefono=input("| Digite su número de telefono: ")
        correo=input("| Escriba su correo: ")
        empresa=(input("| Escriba el nombre de su empresa: "))
        clientes={"identificacion":identificacion,"nombre":nombre,"direccion":direccion,"telefono":telefono,"correo":correo,"empresa":empresa}
    if op==2:
        print("\n========================================")
        print(">>>      INFORMACIÓN DEL CLIENTE    <<<")
        print("========================================\n")
        print("|identificacion: ", clientes["identificacion"])
        print("|Nombre: ", clientes["nombre"])
        print("|Dirección: ", clientes["direccion"])
        print("|Correo: ", clientes["correo"])
        print("|Empresa: ", clientes["empresa"])
    if op==3:
        del clientes["identificacion"]
        print("Cliente eliminado con exito!...")
        
    if op==4:
        exit
        
    print("\n========================================")
    print(">>>      INFORMACIÓN DEL CLIENTE    <<<")
    print("========================================\n")
    print("              --- Menú ---")
    print("|1) Añadir cliente.")
    print("|2) Mostrar cliente.")
    print("|3) Eliminar cliente. ")
    print("|4) Salir.")
    print("----------------------------------------")
    op=int(input("Digite la opción seleccionada: "))

    




