#Diseñe una app que permita al usuario ingresar fruta, cantidad  y el precio unitario y lo almacene en un diccionario llamado factura. despues debe mostrar un mensaje concatenado donde aparece el nombre de la fruta, su valor, la cantidad y el total.
print("¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬")
print("        REGISTRO DE FACTURA")
print("¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬")
fruta=str(input("Ingrese el nombre de la fruta: "))
precio=float(input("Digite el precio de la fruta: "))
cantidad=int(input("Digite la cantidad: "))
factura={"fruta":fruta,"precio":precio,"cantidad":cantidad}
print("\n----------------------------------")
print("<---          FACTURA         --->\n")
print("Fruta :", factura["fruta"], " \nValor: ", factura["precio"], " \nCantidad: ", factura["cantidad"], " \nTotal: ", (precio*cantidad))


