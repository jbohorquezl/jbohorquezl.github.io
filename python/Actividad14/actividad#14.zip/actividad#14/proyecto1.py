#Diseñe una app que permita al usuario nombre, edad, dirección y telefono; estos datos se deben almacenar en un dicionario llamado persona, estos datos se deben mostrar por pantalla de forma concatenada. ejemplo: Juan tiene 17 años vive en la Calle 8 #27-18a y su número de telefono es 1234567
print("------------------------------")
print("      REGISTRO PERSONAL")
print("------------------------------")
nombre=str(input("Digite su nombre: "))
edad=int(input("Digite su edad: "))
direccion=str(input("Digite su dirección: "))
telefono=int(input("Digite su telefono: "))
persona={"nombre":nombre,"edad":edad,"dirrecion":direccion,"telefono":telefono}
print("\nRegistro: ")
print(persona["nombre"], "tiene ", persona["edad"], " años, vive en: ", persona["dirrecion"], " y su número de telefono es: ", persona["telefono"])

