#Diseñe un algoritmo que ingrese un valor de ingreso y un valor de gastos
# Si el ingreso es mayor al gasto es GANANCIA sino es PERDIDA.

x=float(input("Ingrese el valor de ingreso: ($)"))
y=float(input("Ingrese el valor de sus gastos: ($)"))

if x>y:
    print("Esta generando GANANCIAS")
else:
    print("Esta generando PERDIDAS")