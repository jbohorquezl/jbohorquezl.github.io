#Diseñe un algoritmo que ingrese una nota; Si la nota es mayor igual a 3 entonces es APROBADO, sino, REPROBADO.

n=float(input("Ingrese su nota: "))

if n>=3:
    print("Aprobado")
else: 
    print("No aprobado")