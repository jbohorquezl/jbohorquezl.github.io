#app que al ingresar un número diga si es positivo o negativo

n=int(input("Digite el número: "))

if n>0:
    print("El número ",n," es positivo.")
else:
    print("El número ",n," es negativo")