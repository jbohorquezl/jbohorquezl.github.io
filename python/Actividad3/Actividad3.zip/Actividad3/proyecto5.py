#Diseñe un algoritmo que ingrese un número entero y diga si es PAR o IMPAR.

n=int(input("Ingrese un número: "))

if n %2==0:
    print("El número ",n," es Par")
else:
    print("El número ",n," es Impar")
    