#Diseñe un algoritmo que ingrese la edad y diga si es MAYOR DE EDAD o MENOR DE EDAD

n=int(input("Ingrese su edad: "))

if n>=18:
    print("Es Mayor de Edad")
else:
    print("Es Menor de Edad")