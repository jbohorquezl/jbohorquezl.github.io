#Diseñar un agoritmo para un almacen de zapatos que tiene pormoción de descuento para vender al por mayor, esta dependera del número de zapatos que se compren.
#Si son menos de 10, no hay descuento
#Si son mas o igual de 10 y menos de 20 se les dara un 10% de descuento sobre el total de la compra
#Si el número de zapatos es mayor de 20 pero menor de 30, se le otorga un 20% de descuento
#Y si son mas de treinta zapatos se otorgara un 40% de descuento.  

zap=int(input("Ingrese la cantidad de Zapatos: "))
vzap=float(input("Ingrese el valor del par de Zapatos($): "))
if zap<10:
    subtotal=zap*vzap
    print("No hay descuento")
    print("Total a Pagar: $", subtotal)
elif zap >=10 and zap<20:
    subtotal=zap*vzap
    descuento=subtotal*0.10
    vtotal=subtotal-descuento
    print("Obtuvo un descuento del 10% de su compra que equivale a: $",descuento)
    print("Total a pagar: $", vtotal)
elif zap>=20 and zap<30:
    subtotal=zap*vzap
    descuento=subtotal*0.20
    vtotal=subtotal-descuento
    print("Obtuvo un descuento del 20% de su compra que equivale a: $",descuento)
    print("Total a pagar: $", vtotal)
elif zap>=30:
    subtotal=zap*vzap
    descuento=subtotal*0.40
    vtotal=subtotal-descuento
    print("Obtuvo un descuento del 40% de su compra que equivale a: $",descuento)
    print("Total a pagar: $", vtotal)
else:
    print("Por favor verifique los datos ingresados...")