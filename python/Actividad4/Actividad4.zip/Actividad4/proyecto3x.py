#Diseñe un algoritmo que simule la presión arterial:

#si la presion arterial sistolica es menor a 90 su clasificación es baja
#si la presion arterial sistolica es menor a 120 su clasificación es normal
#si la presion arterial sistolica es mayor e igual a 120 y menor e igual a 139 su clasificación es prehipertension
#si la presion arterial sistolica es mayor e igual a 140 y menor e igual a 159 su clasificación es Alta: prehipertension fase 1
#si la presion arterial sistolica es mayor o igual a 160 su clasificación es Alta: prehipertension fase 1


pas=float(input("Digite la presión arterial del paciente:"))

if pas<90:
    print("El paciente tiene una presion arterial Baja")
elif pas>=90 and pas<120:
    print("El paciente tiene una presion arterial Normal")
elif pas>=120 and pas<139:
    print("El paciente tiene Hipertension") 
elif pas>=140 and pas<159:
    print("El paciente tiene una Alta: hipertension fase 1")
elif pas>160:
    print("El paciente tiene una Alta: hipertension fase 2")
else:
    print("Por favor verifique el dato ingresado...")