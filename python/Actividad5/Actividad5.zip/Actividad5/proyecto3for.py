#App que muestre los números del 1 al 100

i=2
while i<=100:
    print(i)
    i=i+2