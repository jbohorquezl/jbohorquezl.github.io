#Diseñar en python las siguentes listas y realizar su recorrrido
# 1) Lista de libros con 7 posiciones.
# 2) Lista de plantas medicinales con 9 posiciones.
# 3) Lista de lenguajes de programación con 5 posiciones.
# 4) Lista de colores con 8 posiciones.

#Array Lista: Añade un elemento al vector.
libros = ["El mundo de Sofia","Cien años de soledad","Crimen y castigo","Harry Potter","El diario de Ana Frank","La comedia humana","La divina comedia"]
#Añadimos un elemento a la lista 
libros.append("La Biblia")
#Eliminar un elemento del vector
#Método por posición
libros.pop(6)
#Método por valor
libros.remove("Crimen y castigo")
print("<--- Libros: --->")
for x in libros:
    print(x,)
print("\n")
lonl = len(libros)
print("La Longitud de los Datos es: ", lonl)

plantas_medicinales = ["Manzanilla","Aloe Vera","Ajo","Eucalipto","Jengibre","Orégano","Yuca","Apio","Caléndula"]
#Añadimos un elemento a la lista 
plantas_medicinales.append("Diente de león")
#Eliminar un elemento del vector
#Método por posición
plantas_medicinales.pop(6)
#Método por valor
plantas_medicinales.remove("Eucalipto")
print("\n")
print("<--- Plantas medicinales: --->")
for p in plantas_medicinales:
    print(p)
print("\n")
lonp = len(plantas_medicinales)
print("La Longitud de los Datos es: ", lonp)
#Eliminar un elemento del vector
    
leng = ["Python","Java","C","C++","JavaScript"]
#Añadimos un elemento a la lista 
leng.append("PHP")
#Eliminar un elemento del vector
#Método por posición
leng.pop(4)
#Método por valor
leng.remove("Python")
print("\n")
print("<--- Lenguajes de Programación: --->")
for l in leng:
    print(l,)
print("\n")
lonlp = len(leng)
print("La Longitud de los Datos es: ", lonlp)
#Eliminar un elemento del vector
    
col = ["Amarillo","Azul","Rojo","Cafe","Verde","Purpura","naranja","negro"]
#Añadimos un elemento a la lista 
col.append("Blanco")
#Eliminar un elemento del vector
#Método por posición
col.pop(6)
#Método por valor
col.remove("Purpura")
print("\n")
print("<--- Colores: --->")
for c in col:
    print(c)
print("\n")
lonc = len(col)
print("La Longitud de los Datos es: ", lonc)
#Eliminar un elemento del vector