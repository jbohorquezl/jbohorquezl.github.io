#Diseñe una app que reciba una lista vacia, dicha lista el usuario define su tamaño y los valores de cada elemento
#La app debe mostrar los valores de la lista actualizada

nombres = []
#Definimos un tamaño para las listas
tamaño = int(input("¿ Tamaño de la lista ?: "))
#Recorrer la lista
for i in range (tamaño):
    print("Ingrese los datos del aprendiz: ", i + 1)
    nombre = input("Nombre del aprendiz: " )
    nombres.append(nombre)
print("Los aprendices son: ")
#Mostrar lista
for i in range(tamaño):
    print("-------------------------")
    #nombres.sort para ordenar alfabeticamente
    print(nombres.sort(), "Nombre: ", nombres[i])
print("-------------------------")
