#Diccionario: Busqueda por clave
print("--------------------------------------------------")
print("Dicionario de Departamentos:\n")
dic={"Sucre":"Sincelejo","Cordoba":"Monteria","Bolivar":"Cartagena","Atlantico":"Barranquilla","Cesar":"Valledupar","Antioquia":"Medellín","Boyaca":"Tunja","Cundinamarca":"Bogotá","Tolima":"Ibague","Risaralda":"Pereira","Quindio":"Armenia","Magdalena":"Santa Marta","Santander":"Bucaramanga","Caldas":"Manizales","Valle del Cauca":"Cali","Chocó":"Quibdó","Meta":"Villavicencio","Ámazonas":"Leticia","La Guajira":"Riohacha","Norte de Santander":"Cúcuta","Arauca":"Arauca","Cauca":"Popayán","Caquetá":"Florencia","Guainía":"Ínirida","Huila":"Neiva","Guaviare":"San José del Guaviare","Nariño":"Pasto","Putumayo":"Mocoa","San Andrés y Providencia":"San Andrés","Vaupés":"Mitú","Vichada":"Puerto Carreño"}
print(dic["Sucre"])
print("--------------------------------------------------")

#Diseñe un diccionario con las marcas de vehiculos y los modelos debe tener mínimo un tamaño de 10 elementos
print("Diccionarios de Vehiculos:\n")
vehiculos={"Volkswagen":"Volkswagen Arteon","Audi":"Audi e-tron GT","Toyota":"Toyota Prius","Nissan":"Nissan Ariya","Renault":"Renault Espace","Alfa Romeo":"Alfa Romeo 145","Ferrari":"Ferrari Enzo","Honda":"Honda CR-V","KIA":"KIA Stinger","Mercedes-Benz":"Mercedes-Benz Clase E","Lamborghini":"Lamborghini Countach","Bugatti":"Bugatti Chiron Super Sport 300+"}
print(vehiculos["Bugatti"])
print("--------------------------------------------------")


print("Dicionario de frutas:\n")
Frutas={"Dulces":["Sandia","Papaya","Guayaba Dulce","Piña"],"Citricas":["Limón","Mandarina","Naranja","Toronja"],"Secos":["Nuez","Avellanas","Pistachos","Almendras"],"Neutras":["Aguacate","Coco","Aceituna","Maní"]}
print(Frutas["Dulces"])
print("--------------------------------------------------")


print("Dicionario de Personas:\n")
Personas={"Jesús":{"Id":"1103099948","Edad":"17","Sexo":"M","Cel":"3229103725","Correo":"jesusbohorquez2005@gmail.com"},"Andrus":{"Id":"1100546856","Edad":"12","Sexo":"M","Cel":"3106103782","Correo":"andrus@gmail.com"},"Sebastian":{"Id":"1101056879","Edad":"13","Sexo":"M","Cel":"3221452358","Correo":"sebas@gmail.com"},"Wendy":{"Id":"1101023578","Edad":"18","Sexo":"F","Cel":"3002564789","Correo":"wisabel@gmail.com"},"Brallan":{"Id":"1099948533","Edad":"19","Sexo":"M","Cel":"3145678230","Correo":"brallanm@gmail.com"}}
print(Personas["Jesús"])
print("--------------------------------------------------")

print("--------------------------")
print("DICIONARIO DE VETERINARIA:")
print("--------------------------")
Can={"Yako":{"Nombre":"Yako","Raza":"Pastor Aleman","Fecha de Nacimiento":"2014/07/05","Color":"Marrón Fuego","Dueño":"Adrian","Telefono":"651336640","Visitas al Veterinario":"4"},"Firulay":{"Nombre":"Firulay","Raza":"Dalmata","Fecha de Nacimiento":"2015/04/21","Color":"blanco","Dueño":"Marcos","Telefono":"456852357","Visitas al Veterinario":"3"},"Junior":{"Nombre":"Junior","Raza":"Labrador","Fecha de Nacimiento":"2019/09/19","Color":"negro","Dueño":"Andres","Telefono":"369753654","Visitas al Veterinario":"2"},"Chocolate":{"Nombre":"Chocolate","Raza":"pitbull","Fecha de Nacimiento":"2010/01/19","Color":"chocolate","Dueño":"Mateo","Telefono":"254789633","Visitas al Veterinario":"6"},"Golfo":{"Nombre":"Golfo","Raza":"husky","Fecha de Nacimiento":"2012/10/20","Color":"Negro azabache","Dueño":"Manuel","Telefono":"985647310","Visitas al Veterinario":"6"}}
print(Can["Golfo"])