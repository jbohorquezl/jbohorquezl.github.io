#Algoritmo que calcule El área de un circulo

n=float(input("Ingrese el valor del radio: "))
area=n*n*3.14159265259
print("El area del circulo de radio ", n, " es: ", area)