#Algoritmo que calcule el promedio de tres notas

a=float(input("Ingrese la primera nota: "))
b=float(input("Ingrese la segunda nota: "))
c=float(input("Ingrese la terccera nota: "))

nota=(a+b+c)/3

print("El promedio es: ", nota)