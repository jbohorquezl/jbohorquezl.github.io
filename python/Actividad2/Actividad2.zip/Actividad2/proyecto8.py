#Perimetro de un rectangulo

a=float(input("Digite la base del rectangulo: "))
b=float()(input("Digite la altura del rectangulo: "))
c=a+a+b+b
print("El perimetro del rectangulo es: ",c)