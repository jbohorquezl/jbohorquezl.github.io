#Área de un rectángulo

a=int(input("Digite la base del rectangulo: "))
b=int(input("Digite la altura del rectangulo: "))
c=a*b
print("El area del rectangulo es: ",c)