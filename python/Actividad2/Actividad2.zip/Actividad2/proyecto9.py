#Conversión de dólar a Peso colombiano

a=float(input("Ingrese el valor ($USD): "))
b=a*4.462
print(a," es equivalente a ", b , " COP")