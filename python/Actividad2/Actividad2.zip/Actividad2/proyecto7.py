#Diseñe un algoritmo que al ingresar un número el usuario: 
# a) Calcule el doble de un número y muestre en pantalla
# b) Calcule el triple y muestre en pantalla de un número

a=int(input("Ingresa un número: "))
doble=a*2;
triple=a*3;

print("El doble es: ", doble)
print("El triple es: ", triple)