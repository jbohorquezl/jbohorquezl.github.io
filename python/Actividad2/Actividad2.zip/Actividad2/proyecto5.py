#Algoritmo que opere las funciones de una calculadora
n1=int(input("Ingresa el primer número: "))
n2=int(input("Ingresa el segundo número: "))

Sum=n1+n2
res=n1-n2
mul=n1*n2
div=n1/n2

print("La suma es ", Sum)
print("La resta es ", res)
print("La multiplicación es ", mul)
print("La división es ", div)