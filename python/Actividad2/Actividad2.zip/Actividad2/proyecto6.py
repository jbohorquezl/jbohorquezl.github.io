#algorito que calcule el 5% del descuento de un salario
salario=float(input("Ingresa el salario ($): "))
descuento=salario*0.05
dest=salario-descuento
print("El descuento es: ", descuento)
print("Su salario con descuento es: ", dest)