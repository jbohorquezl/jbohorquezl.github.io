#Algoritmo que al ingresar dos numeros los sume


a=int(input("Digite el primer número: "))
b=int(input("Digite el segundo número: "))
c=a+b
print("La suma de ", a ," + ", b ," es: ",c)